package com.events.bootcamp.productcliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
