package com.events.bootcamp.desafServer.controller;


import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestTemplate {
	
	@GetMapping("/prueba")
    public String llamada() {
 
        return String.valueOf("Prueba:" +Math.random());
    }
	
	public void estado1() {
		System.out.println();
	}
}
