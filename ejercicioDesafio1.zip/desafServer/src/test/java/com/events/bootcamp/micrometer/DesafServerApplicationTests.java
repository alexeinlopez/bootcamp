package com.events.bootcamp.micrometer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
