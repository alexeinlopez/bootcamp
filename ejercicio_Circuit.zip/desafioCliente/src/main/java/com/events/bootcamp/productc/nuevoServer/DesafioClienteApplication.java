package com.events.bootcamp.productc.nuevoServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioClienteApplication.class, args);
		
		
		
		
		
	}

}
