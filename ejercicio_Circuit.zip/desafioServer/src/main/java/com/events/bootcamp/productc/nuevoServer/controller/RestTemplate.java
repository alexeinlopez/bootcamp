package com.events.bootcamp.productc.nuevoServer.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestTemplate {
	
	@GetMapping("/llamada")
    public String llamada() {
 
        return "Llamada desde cliente";
    }
	

}
