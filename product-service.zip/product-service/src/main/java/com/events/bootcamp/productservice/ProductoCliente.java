package com.events.bootcamp.productservice;

public class ProductoCliente {
	

}
