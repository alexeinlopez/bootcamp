package ejercicioSingleton;

public class persona {

	private String nombre;
	private static persona personaUnica;

	private persona(String nombre) {
		this.nombre = nombre;
		System.out.println("Nombre: " + this.nombre);
	}

	public static persona getSingletonInstance(String nombre) {
		if (personaUnica == null){
			personaUnica = new persona(nombre);
		}
		else{
			System.out.println("No se puede crear "+ nombre + " porque ya existe otro nombre.");
		}

		return personaUnica;
	}
}