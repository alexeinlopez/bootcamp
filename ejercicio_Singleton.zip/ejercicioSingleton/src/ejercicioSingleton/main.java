package ejercicioSingleton;

public class main {

	public static void main(String[] args) {
		
		String nombre1="Pedro";
		
		persona.getSingletonInstance(nombre1);
		
		String nombre2="Pepe";
		
		persona.getSingletonInstance(nombre2);
	}
}