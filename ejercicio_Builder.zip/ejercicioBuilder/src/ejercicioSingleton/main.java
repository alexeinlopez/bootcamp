package ejercicioSingleton;

public class main {

	public static void main(String[] args) {
		
	personaBuilder builder = new personaBuilder();
	
	persona nueva = builder.edad(15).apellidos("L�pez").Builder();
	
	System.out.println(nueva.getEdad());
	System.out.println(nueva.getApellidos());
		
	}
}