package ejercicioSingleton;

public interface Builder {
	
	public default void personaBuilder() {

	}

	public static personaBuilder edad (int edad) {
		return null;
		
	}
	
	public static personaBuilder apellidos (String apellidos) {
		return null;
		
	}
	
	public static persona Builder() {
		return null;
	}
	
		
}
