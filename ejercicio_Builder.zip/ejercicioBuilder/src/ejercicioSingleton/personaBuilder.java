package ejercicioSingleton;

public class personaBuilder implements Builder{

	private persona nueva=new persona();

	public personaBuilder() {

	}

	public personaBuilder edad (int edad) {
		this.nueva.setEdad(edad);
		return this;
	}
	
	public personaBuilder apellidos (String apellidos) {
		this.nueva.setApellidos(apellidos);
		return this;
	}
	
	public persona Builder() {
		return nueva;
	}
	
	
	

	
}