module ejercicioSingleton {
}