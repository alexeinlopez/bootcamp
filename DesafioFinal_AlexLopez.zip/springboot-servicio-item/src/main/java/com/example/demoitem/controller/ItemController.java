package com.example.demoitem.controller;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoitem.models.Item;
import com.example.demoitem.models.Producto;
import com.example.demoitem.services.ItemServiceI;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

@RestController
public class ItemController {
	
	@Autowired
	private CircuitBreakerFactory cb;
	
	@Autowired
	private ItemServiceI itemService;
	
	private Counter counter;
	
	public ItemController(MeterRegistry registry) {
		this.counter = Counter.builder("invocacionesItem").description("Total invocaciones al controller Item").register(registry);
	}
	
	@GetMapping("/listar")
	public List<Item> listar(){
		this.counter.increment();
		return itemService.findAll();
	}
	
	@GetMapping("/detalle/{id}/cantidad/{cantidad}")
	public Item detalle(@PathVariable Long id, @PathVariable Integer cantidad) {
		this.counter.increment();
		return cb.create("items").run(() -> itemService.findById(id, cantidad), e -> metodoAlternativo(id, cantidad, e));
	}
	
	public Item metodoAlternativo(Long id, Integer cantidad, Throwable exception) {
		System.out.println(exception.getMessage());
		
		Item item = new Item();
		Producto producto = new Producto();
		
		item.setCantidad(cantidad);
		producto.setId(id);
		producto.setNombre("Sony");
		producto.setPrecio(400.99);
		item.setProducto(producto);
		
		return item;
	}
}
