package com.example.demoitem.services;

import java.util.List;

import com.example.demoitem.models.Item;

public interface ItemServiceI {

	public List<Item> findAll();
	
	public Item findById(Long id, Integer cantidad);
}
