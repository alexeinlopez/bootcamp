package com.example.demo.models.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.models.entity.Producto;

public interface ProductoDaoI extends CrudRepository<Producto, Long>{

}
