package com.example.demo.services;

import java.util.List;

import com.example.demo.models.entity.Producto;

public interface ProductoServiceI {
	
	public List<Producto> findAll();
	
	public Producto findById(Long id);

}
