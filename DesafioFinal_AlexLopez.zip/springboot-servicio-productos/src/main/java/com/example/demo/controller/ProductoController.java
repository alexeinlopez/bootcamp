package com.example.demo.controller;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.entity.Producto;
import com.example.demo.services.ProductoServiceI;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

@RestController
public class ProductoController {

	@Autowired
	private ProductoServiceI productoService;
	
	private Counter counter;
	
	public ProductoController(MeterRegistry registry) {
		this.counter = Counter.builder("invocacionesProducto").description("Total invocaciones al controller Producto").register(registry);
	}
	
	@GetMapping("/listar")
	public List<Producto> listar(){
		this.counter.increment();
		return productoService.findAll();
	}
	
	@GetMapping("/detalle/{id}")
	public Producto detalle(@PathVariable Long id) throws InterruptedException {
		if(id.equals(10L)) {
			throw new IllegalStateException("Producto no encontrado");
		}
		if(id.equals(7L)) {
			TimeUnit.SECONDS.sleep(5L);
		}
		this.counter.increment();
		return productoService.findById(id);
	}
}
