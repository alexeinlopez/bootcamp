package com.events.bootcamp.prueba;

class PruebaApplicationTests {

	
	void contextLoads() {
	}

}
