package com.events.bootcamp.prueba;

class StarteClientApplicationTests {

	
	void contextLoads() {
	}

}
