package com.events.bootcamp.micrometer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Actuator1Application {

	public static void main(String[] args) {
		SpringApplication.run(Actuator1Application.class, args);
	}

}
