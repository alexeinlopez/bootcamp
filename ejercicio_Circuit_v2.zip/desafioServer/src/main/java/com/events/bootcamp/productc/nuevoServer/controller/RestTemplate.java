package com.events.bootcamp.productc.nuevoServer.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestTemplate {
	
	@GetMapping("/prueba")
    public String llamada() {
 
        return String.valueOf("Prueba: "+Math.random());
    }
}
