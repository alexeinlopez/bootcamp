package com.events.bootcamp.productc.nuevoServer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class DesafioClienteApplication implements CommandLineRunner {
	
	@Value("${spring.cloud.config.uri}")
	private String url;

	public static void main(String[] args) {
		SpringApplication.run(DesafioClienteApplication.class, args);
	}
	
	@Override
	public void run(String ...args) throws Exception {
		RestTemplate plantilla = new RestTemplate();
		for(int i=0; i<5; i++) {
			System.out.println(plantilla.getForObject(url + "/prueba", String.class));
		}
	}

}
