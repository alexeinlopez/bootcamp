package com.events.bootcamp.productc.nuevoServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductConfigServer2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
