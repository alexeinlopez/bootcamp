package com.events.bootcamp.productc.configServer2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductConfigServer2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
