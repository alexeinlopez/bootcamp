package com.events.bootcamp.productc.configServer2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductConfigServer2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductConfigServer2Application.class, args);
	}

}
